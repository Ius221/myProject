package com.Ayush.Service;

import com.Ayush.Factory.ConnectionFactory;
import com.Ayush.dao.CustomerDao;
import java.sql.*;

/**
 *
 * @author hacker
 */
public class ModifyBalanceService {

    Statement st;
    ResultSet rs;

    public String withdarwReq(CustomerDao cus) {
        String status = "";
        try {
            st = ConnectionFactory.getStatement();
            rs = st.executeQuery("select * from bank where name = '" + cus.getName() + "'");
            if (rs.next()) {
                int amn = rs.getInt("amount");
                amn -= cus.getAmount();
                if (amn > 0) {
                    int rowCount = st.executeUpdate("update bank set amount = " + amn + " where name = '" + cus.getName() + "'");
                    if (rowCount != 0) {
                        status = "success";
                        cus.setAmount(amn);
                    } else {
                        status = "failed";
                    }
                } else {
                    status = "insufficient";
                }
            }
        } catch (Exception e) {
            status = "failed";
            e.printStackTrace();
        }

        return status;
    }

    public String depositReq(CustomerDao cus) {
        String status = "";

        try {
            st = ConnectionFactory.getStatement();
            rs = st.executeQuery("select * from bank where name = '" + cus.getName() + "'");
            if (rs.next()) {
                int amn = rs.getInt("amount");
                amn += cus.getAmount();
                int rowCount = st.executeUpdate("update bank set amount = " + amn + " where name = '" + cus.getName() + "'");
                if (rowCount != 0) {
                    status = "success";
                    cus.setAmount(amn);
                } else {
                    status = "failed";
                }
            }
        } catch (Exception e) {
            status = "failed";
            e.printStackTrace();
        }

        return status;
    }
}
