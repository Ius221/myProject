package com.Ayush.Service;

import com.Ayush.Factory.ConnectionFactory;
import com.Ayush.dao.CustomerDao;
import java.sql.*;
/**
 *
 * @author hacker
 */
public class BalanceEnquiryService {
    public String balanceEnquiry(CustomerDao cus){
        String status = "failed";
        
        try{
            Statement st = ConnectionFactory.getStatement();
            ResultSet rs = st.executeQuery("select * from bank where name = '"+cus.getName()+"' and accNo = '"+cus.getAccNo()+"';");
            if(rs.next()){
                status = "success";
                cus.setAmount(rs.getInt("amount"));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return status;
    }
}
