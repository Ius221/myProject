package com.Ayush.Service;

import com.Ayush.Factory.ConnectionFactory;
import java.sql.*;

/**
 *
 * @author hacker
 */
public class CloseAccountService {

    public String accClose(String name, String accNo) {
        String status = "failed";
        try {
            Statement st = ConnectionFactory.getStatement();
            int rowCount = st.executeUpdate("delete from bank where name = '"+name+"' and accNo = '"+accNo+"';");
            if(rowCount != 0){
                status = "success";
            }
        } catch (Exception e) {
            status = "exception";
            e.printStackTrace();
        }

        return status;
    }

}
