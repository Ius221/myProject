package com.Ayush.Service;

import com.Ayush.Factory.ConnectionFactory;
import com.Ayush.dao.CustomerDao;
import java.sql.*;

/**
 *
 * @author hacker
 */
public class OpenAccountService {
//name  | accNo | mail  | phno | nName | amount

    public String openAccn(CustomerDao cus) {
        String status = "failed";
        try {
            Statement st = ConnectionFactory.getStatement();
            int rowCount = st.executeUpdate("insert into bank(name,mail,phno,nName,amount) values ('" + cus.getName() + "','" + cus.getMail() + "','" + cus.getPhoneNo() + "','" + cus.getnName() + "'," + cus.getAmount() + "); ");
            if (rowCount != 0) {
                ResultSet rs = st.executeQuery("select * from bank where name = '" + cus.getName() + "';");
                if (rs.next()) {
                    cus.setAccNo(rs.getString("accNo"));
                    status = "success";
                }
                else{
                    status = "failed";
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }
}
