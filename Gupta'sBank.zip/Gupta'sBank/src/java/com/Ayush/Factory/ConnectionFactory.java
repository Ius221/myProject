package com.Ayush.Factory;

import java.sql.*;

/**
 *
 * @author hacker
 */
public class ConnectionFactory {

    private static Connection conn;
    private static Statement st;
    private static final String url = "jdbc:mysql://localhost:3306/GuptaBank";
    private static final String uname = "root";
    private static final String pass = "Ayush@123";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, uname, pass);
            st = conn.createStatement();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    public static Statement getStatement(){
        return st;
    }

}
