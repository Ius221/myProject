package com.Ayush.Servlet;

import com.Ayush.Service.OpenAccountService;
import com.Ayush.dao.CustomerDao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author hacker
 */
@WebServlet(urlPatterns = {"/OpenAccount", "/openAccn"})
public class OpenAccount extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String mail = request.getParameter("mail");
        String pno = request.getParameter("pno");
        String nName = request.getParameter("nName");
        int amount = Integer.parseInt(request.getParameter("amount"));

        CustomerDao custDao = new CustomerDao();
        custDao.setName(name);
        custDao.setMail(mail);
        custDao.setPhoneNo(pno);
        custDao.setnName(nName);
        custDao.setAmount(amount);

        OpenAccountService oAS = new OpenAccountService();
        String status = oAS.openAccn(custDao);

        PrintWriter out = response.getWriter();
        /* TODO output your page here. You may use following sample code. */
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Servlet OpenAccount</title>"
                + "<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\n"
                + "<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>"
                + "<link href=\"https://fonts.googleapis.com/css2?family=Graduate&family=Rokkitt:ital,wght@0,100..900;1,100..900&display=swap\" rel=\"stylesheet\">\n"
                + "<link href=\"https://fonts.googleapis.com/css2?family=Glegoo:wght@400;700&family=Graduate&family=Rokkitt:ital,wght@0,100..900;1,100..900&display=swap\" rel=\"stylesheet\">\n"
                + "<style>\n"
                + "            *{\n"
                + "                margin: 0px;\n"
                + "                padding: 0px;\n"
                + "            }\n"
                + "            body{\n"
                + "                background-color: #EBD3F8;\n"
                + "            }\n"
                + "            h1, h3{\n"
                + "                font-family: \"Rokkitt\", serif;\n"
                + "                text-align: center;\n"
                + "            }"
                + "</style>");
        out.println("</head>");
        out.println("<body>");
        if (status.equals("success")) {
            out.println("<br><br><h1>Your Account Number is "+custDao.getAccNo()+"</h1>");
        } else {
            out.println("<br><br><h1>Failed</h1>");
        }
        out.println("</body>");
        out.println("</html>");
    }

}
