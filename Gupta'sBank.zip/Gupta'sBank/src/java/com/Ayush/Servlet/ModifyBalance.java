package com.Ayush.Servlet;

import com.Ayush.Service.ModifyBalanceService;
import com.Ayush.dao.CustomerDao;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author hacker
 */
@WebServlet(name = "ModifyBalance", urlPatterns = {"/ModifyBalance", "/modifyBalance"})
public class ModifyBalance extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String name = request.getParameter("name");
        String accNo = request.getParameter("accNo");
        int amount = Integer.parseInt(request.getParameter("amount"));
        String opt = request.getParameter("action");

        CustomerDao cusDao = new CustomerDao();
        cusDao.setName(name);
        cusDao.setAccNo(accNo);
        cusDao.setAmount(amount);

        ModifyBalanceService modBal = new ModifyBalanceService();
        String status;
        if (opt.equals("withdraw")) {
            status = modBal.withdarwReq(cusDao);
        } else {
            status = modBal.depositReq(cusDao);
        }

        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ModifyBalance</title>"
                    + "<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\n"
                    + "<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>"
                    + "<link href=\"https://fonts.googleapis.com/css2?family=Graduate&family=Rokkitt:ital,wght@0,100..900;1,100..900&display=swap\" rel=\"stylesheet\">\n"
                    + "<link href=\"https://fonts.googleapis.com/css2?family=Glegoo:wght@400;700&family=Graduate&family=Rokkitt:ital,wght@0,100..900;1,100..900&display=swap\" rel=\"stylesheet\">\n"
                    + "<style>\n"
                    + "            *{\n"
                    + "                margin: 0px;\n"
                    + "                padding: 0px;\n"
                    + "            }\n"
                    + "            body{\n"
                    + "                background-color: #EBD3F8;\n"
                    + "            }\n"
                    + "            h1, h3{\n"
                    + "                font-family: \"Rokkitt\", serif;\n"
                    + "                text-align: center;\n"
                    + "            }"
                    + "</style>");
            out.println("</head>");
            out.println("<body>");
            if (status.equals("success")) {
                out.println("<br><br><h1>Money Inserted Successfully</h1>");
            } else if (status.equals("insufficient")) {
                out.println("<br><br><h1>Insufficient Balance</h1>");
            } else {
                out.println("<br><br><h1>Failed</h1>");
            }
            out.println("</body>");
            out.println("</html>");
        }
    }

}
