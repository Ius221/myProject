package com.Ayush.dao;

/**
 *
 * @author hacker
 */
public class CustomerDao {
    private static String name;
    private static String accNo;
    private static String mail;
    private static String phoneNo;
    private static String nName;
    private static int amount;

    public static String getName() {
        return name;
    }

    public static void setName(String name) {
        CustomerDao.name = name;
    }

    public static String getAccNo() {
        return accNo;
    }

    public static void setAccNo(String accNo) {
        CustomerDao.accNo = accNo;
    }

    public static String getMail() {
        return mail;
    }

    public static void setMail(String mail) {
        CustomerDao.mail = mail;
    }

    public static String getPhoneNo() {
        return phoneNo;
    }

    public static void setPhoneNo(String phoneNo) {
        CustomerDao.phoneNo = phoneNo;
    }

    public static String getnName() {
        return nName;
    }

    public static void setnName(String nName) {
        CustomerDao.nName = nName;
    }

    public static int getAmount() {
        return amount;
    }

    public static void setAmount(int amount) {
        CustomerDao.amount = amount;
    }
    
}
