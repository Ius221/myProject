
package com.Ayush.Service;

import java.sql.*;

public class UserService {

    Connection conn = null;
    Statement st = null;
    ResultSet rs = null;
    String dbname = "root";
    String url = "jdbc:mysql://localhost:3306/Servlet";
    String dbpass = "Ayush@123";
    
    public UserService() {
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
        }
        catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        
        try{
            conn = DriverManager.getConnection(url,dbname,dbpass);
            st = conn.createStatement();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        
    }
    
    public String checkLogin(String uname, String upwd){
        String status = "null";
     
        try{
            rs = st.executeQuery("select * from User where name = '"+uname+"' and password ='"+upwd+"';");
            boolean b = rs.next();
            if(b == true){
                status = "success";
            }
            else{
                status = "Failure";
            }
        }catch(Exception e){
            status = "failure";
            e.printStackTrace();
        }
        
        return status;
    }
    
    public String registration(String uname, String upwd, String uemail, String umobile){
        String status = "val";

        try{
            rs = st.executeQuery("select * from User where name = '"+uname+"' and password ='"+upwd+"';");
            if(!rs.next()){
                int val = st.executeUpdate("insert into User(name, password, email, phone) values('"+uname+"','"+upwd+"','"+uemail+"',"+umobile+");");
                if(val == 0){
                    status = "Failure";
                }
                else{
                    status = "success";
                }                
            }
            else{
                status = "existed";
            }
        }catch(Exception e){
            status = "failure";
            e.printStackTrace();
        }
        
        return status;
    }
}
