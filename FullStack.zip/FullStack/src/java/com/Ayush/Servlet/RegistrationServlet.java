
package com.Ayush.Servlet;

import com.Ayush.Service.UserService;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "RegistrationServlet", urlPatterns = {"/RegistrationServlet","/register"})
public class RegistrationServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            UserService userService = new UserService();
            String uname = request.getParameter("uname");
            String upass = request.getParameter("upass");
            String umail = request.getParameter("uemail");
            String uno = request.getParameter("uno");

            String status ;
            status = userService.registration(uname,upass,umail,uno);
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RegistrationServlet</title>");
            out.println("<style>");
            
            out.println("h1{text-align: center;margin-top: 50vh;}");
            
            out.println("</style>");
            out.println("</head>");
            out.println("<body bgcolor=\"#FADF9C\">");

            if(status.equals("success")){
                out.println("<h1>Register Successfull</h1>");
            }
            else if(status.equals("existed")){
                out.println("<h1>User Existed</h1>");
                out.println("<h3>Please select Login</h3>");                                
            }
            else{
                out.println("<h1 style=\"color: red;  \">Registeration Failure</h1> <br> "+status);
            }

            out.println("</body>");
            out.println("</html>");
        }
    }

}
