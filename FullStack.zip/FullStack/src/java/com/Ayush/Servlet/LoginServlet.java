package com.Ayush.Servlet;

import com.Ayush.Service.UserService;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet","/login"})
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
            String uname = request.getParameter("name");
            String upass = request.getParameter("pass");

            UserService userService = new UserService();
            String status = userService.checkLogin(uname, upass);
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet LoginServlet</title>");
            out.println("<style>");
            
            out.println("h1{text-align: center;margin-top: 45vh;}");
            
            out.println("</style>");
            out.println("</head>");
            out.println("<body bgcolor=\"#FADF9C\">");
            if(status.equalsIgnoreCase("success")){
                out.println("<h1>Login Success</h1>");
            }
            else{
                out.println("<h1 style=\"color: red;  \">Login Failure</h1>");
            }
            out.println("</body>");
            out.println("</html>");
        }
    }

}
