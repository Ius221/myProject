package com.Bank.Service;

import com.Bank.Beans.Bank;
import com.Bank.Dao.BankDao;
import com.Bank.Dao.BankDaoImp;
import com.Bank.Factory.DaoFactory;

public class BankServiceImp implements BankService{
    @Override
    public String create(Bank bnk) {
        BankDao bank = DaoFactory.getBankDao();
        return bank.createAccount(bnk);
    }

    @Override
    public String credit(Bank bnk) {
        BankDao obj = DaoFactory.getBankDao();
        return obj.creditAmount(bnk);
    }

    @Override
    public String debit(Bank bnk) {
        BankDao obj = new BankDaoImp();
        return obj.debitAmount(bnk);
    }

    @Override
    public String kyc(String panno) {
        BankDao obj = new BankDaoImp();
        return obj.kycDetails(panno);
    }

    @Override
    public String close(String bnk) {
        BankDao obj = new BankDaoImp();
        return obj.closeAccount(bnk);

    }
}
