package com.Bank.Service;

import com.Bank.Beans.Bank;

public interface BankService {
    public String create(Bank bnk);
    public String credit(Bank bnk);
    public String debit(Bank bnk);
    public String kyc(String panno);
    public String close(String bnk);

}
