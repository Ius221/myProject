package com.Bank.Beans;

public class Bank {
    private String name;
    private String father_name;
    private String address;
    private String panno;
    private int amount;
    private int tmpamount;

    public int getTmpamount() {
        return tmpamount;
    }

    public void setTmpamount(int tmpamount) {
        this.tmpamount = tmpamount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getFather_name() {
        return father_name;
    }

    public void setFather_name(String father_name) {
        this.father_name = father_name;
    }

    public String getPanno() {
        return panno;
    }

    public void setPanno(String panno) {
        this.panno = panno;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
