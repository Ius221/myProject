package com.Bank.Main;

import com.Bank.Beans.Bank;
import com.Bank.Factory.ServiceFactory;
import com.Bank.Service.BankService;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) {

        String Bstatus ;
        String name,fname, address,pan;
        int amount;


        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            BankService bankobj = ServiceFactory.getBankService();
            Bank bnk = null;
            String status = null;


            while (true) {
                    System.out.println("-----------------------------------------");
                    System.out.println("**********WELCOME TO AYUSH BANK**********");
                    System.out.println("-----------------------------------------");
                    System.out.println("Select the options");
                    System.out.println("1. Create Account \n2. Credit Amount \n3. Debit Amount\n4. Get Customer " +
                            "Details\n5" +
                            ". Close Account \n6. Exit");
                    System.out.print("Enter your Options : ");

                    int opt = Integer.parseInt(br.readLine());

                    switch (opt){
                        case 1: {
                            System.out.print("Please provide your Pan no                      :  ");
                            pan = br.readLine();
                            System.out.print("Please provide your Name as per your Pan        :  ");
                            name = br.readLine();
                            System.out.print("Please provide your Father Name as per your Pan :  ");
                            fname = br.readLine();
                            System.out.print("Please provide your Address as per your Pan     :  ");
                            address = br.readLine();

                            bnk = new Bank();

                            bnk.setPanno(pan);
                            bnk.setName(name);
                            bnk.setFather_name(fname);
                            bnk.setAddress(address);

                            Bstatus = bankobj.create(bnk);
                            System.out.println("Status : " + Bstatus);
                        }
                            break;
                        case 2: {
                            System.out.print("Please provide your Pan Number  : ");
                            pan = br.readLine();
                            System.out.print("Please provide your Name        : ");
                            name = br.readLine();
                            System.out.print("Please Enter money              : ");
                            amount = Integer.parseInt(br.readLine());

                            bnk = new Bank();

                            bnk.setPanno(pan);
                            bnk.setName(name);
                            bnk.setTmpamount(amount);
                            Bstatus = bankobj.credit(bnk);
                            System.out.println("Status : " + Bstatus);
                        }
                            break;
                        case 3:{
                            System.out.print("Please provide your Pan Number    : ");
                            pan = br.readLine();
                            System.out.print("Please provide your Name          : ");
                            name = br.readLine();
                            System.out.print("Amount you want to withdraw       : ");
                            amount = Integer.parseInt(br.readLine());

                            bnk = new Bank();
                            bnk.setPanno(pan);
                            bnk.setName(name);
                            bnk.setTmpamount(amount);
                            Bstatus = bankobj.debit(bnk);
                            System.out.println(Bstatus);
                        }
                            break;
                        case 4:{
                            System.out.print("Provide your Pan Number : ");
                            pan = br.readLine();

                            Bstatus = bankobj.kyc(pan);
                            System.out.println(Bstatus);
                        }
                            break;
                        case 5: {
                            System.out.println("Please Enter your Pan Number : ");
                            pan = br.readLine();

                            Bstatus = bankobj.close(pan);
                            System.out.println(Bstatus);
                        }
                            break;
                        case 6: {
                            System.out.println(">< Thakyou for using Ayush Bank ><");
                            System.exit(0);
                        }
                            break;
                        default:
                            System.out.println("Select correct options");
                    }
            }
        }
        catch(Exception e) {
            System.out.println(e.getMessage());
        }
    }
}