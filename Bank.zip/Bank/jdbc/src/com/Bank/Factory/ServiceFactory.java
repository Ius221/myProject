package com.Bank.Factory;

import com.Bank.Service.BankService;
import com.Bank.Service.BankServiceImp;

public class ServiceFactory {
    private static BankService bs = null;
    static{
        bs = new BankServiceImp();
    }
    public static BankService getBankService(){
        return bs;
    }
}
