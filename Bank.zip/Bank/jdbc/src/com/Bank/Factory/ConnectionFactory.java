package com.Bank.Factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
    private static Connection conn;
    //Database path
    //Database used is SQLite
    private static String url = "jdbc:sqlite:/home/hacker/Documents/jdbc_Durgasoft/Bank/Database/Bank.db";

    static {
        try {
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static Connection getConnection(){
        return conn;
    }
}
