package com.Bank.Factory;

import com.Bank.Dao.BankDao;
import com.Bank.Dao.BankDaoImp;

public class DaoFactory {
    private static BankDao df;
    static {
        df = new BankDaoImp();
    }
    public static BankDao getBankDao(){
        return df;
    }

}
