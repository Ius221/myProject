package com.Bank.Dao;

import com.Bank.Beans.Bank;
import com.Bank.Factory.ConnectionFactory;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class BankDaoImp implements BankDao {
    @Override
    public String createAccount(Bank bnk){
        String status = "";
        try{
            Connection conn = ConnectionFactory.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("Select * from Bank where panno = '"+bnk.getPanno()+"';");
            boolean b = rs.next();
            if(b){
                status = "Account Already Existed";
            }
            else{
                int x =
                        st.executeUpdate("insert into Bank values ('"+bnk.getPanno()+"','"+bnk.getName()+"','"+bnk.getFather_name()+"','"+bnk.getAddress()+"',1000);");
                if(x != 0){
                    bnk.setAmount(1000);
                    status = "Account Created Successfully";
                    System.out.println("Your account balance is "+bnk.getAmount());

                }
                else {
                    status = "Acccount Can't Create";
                }

            }
        }
        catch (Exception e){
//            System.out.println("Ayush");
            System.out.println(e.getMessage());
        }

        return status;
    }
    @Override
    public String creditAmount(Bank bnk){
        String status="Default";
        try{
            Connection conn = ConnectionFactory.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from Bank where panno = '"+bnk.getPanno()+"';");
            boolean b = rs.next();
            if(!b){
                status = "Account not found";
            }
            else {
                int preAmount = rs.getInt("amount");
                System.out.println("Your Previous balance is "+preAmount);

                int totalAmount = preAmount + bnk.getTmpamount();
                int count = st.executeUpdate("update Bank set amount = "+totalAmount+" where panno = '"+bnk.getPanno()+
                        "';");
                if (count != 0){
                    status = "Visit Again";
                    System.out.println("Your current balance is : "+totalAmount );
                }
                else {
                    status = "Regretted";
                }
            }
        }
        catch (Exception e){
            status = "Regretted";
            System.out.println(e.getMessage());
        }
        return status;
    }
    @Override
    public String debitAmount(Bank bnk){
        String status = "Default";
        try{
            Connection conn = ConnectionFactory.getConnection();
            Statement st =conn.createStatement();
            ResultSet rs =
                    st.executeQuery("select * from Bank where panno = '"+bnk.getPanno()+"' and name = '"+bnk.getName()+
                    "';");
            if(rs.next()){
                int amount = rs.getInt("amount");
                System.out.println("Previous amount is : "+amount);
                if(amount < bnk.getTmpamount()){
                    System.out.println("Your withdraw amount is larger ");
                    status ="Enter correct amount";
                }
                else {
                    int totalAmount = amount - bnk.getTmpamount();
                    int val =
                            st.executeUpdate("update Bank set amount = "+totalAmount+" where panno = '"+bnk.getPanno()+"';");
                    if (val != 1){
                        status = "Error Happened";
                    }
                    else {
                        System.out.println("Current amount is : " + totalAmount);
                        status = "Visit Again";
                    }
                }
            }
            else {
                System.out.println("Please check Name and Panno");
                status = "Regretted";
            }
        }
        catch (Exception e){
            status = ("Regretted");
            System.out.println(e.getMessage());
        }

        return status;
    }
    @Override
    public String  kycDetails(String panno){

        String status = "Default";

        try{
            Connection conn = ConnectionFactory.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from Bank where panno = '"+panno+"';");
            if(rs.next()){
                System.out.print("Name          : "+rs.getString("name"));
                System.out.print("\nFather Name   : "+rs.getString("fname"));
                System.out.print("\nAddress       : "+rs.getString("address"));
                System.out.print("\nAmount        : "+rs.getInt("amount"));
                status = "\nVisit Again";
            }
            else {
                status = "Account Not Found";
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }
    @Override
    public String closeAccount(String panno) {
        String status = "Default";
        try {
            Connection conn = ConnectionFactory.getConnection();
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("select * from Bank where panno = '" + panno + "';");
            if (rs.next()) {
                st.executeUpdate("delete from bank where panno = '" + panno + "';");
                status = "Account deleted successfully";
            } else {
                status = "Check your Pan Number";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }
}
