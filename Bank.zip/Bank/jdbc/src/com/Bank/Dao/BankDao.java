package com.Bank.Dao;

import com.Bank.Beans.Bank;

public interface BankDao {
    public String createAccount(Bank bnk);
    public String creditAmount(Bank bnk);
    public String debitAmount(Bank bnk);
    public String kycDetails(String panno);
    public String closeAccount(String  bnk);
}
